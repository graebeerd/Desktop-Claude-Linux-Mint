const { app, BrowserWindow, shell, Menu, session } = require('electron');
const path = require('path');
const fs   = require('fs');

// ── Persist window bounds ──────────────────────────────────────────────────
const stateFile = path.join(app.getPath('userData'), 'window-state.json');

function loadState() {
  try { return JSON.parse(fs.readFileSync(stateFile, 'utf8')); }
  catch { return { width: 1280, height: 860 }; }
}

function saveState(win) {
  if (win.isMaximized() || win.isMinimized()) return;
  fs.writeFileSync(stateFile, JSON.stringify(win.getBounds()));
}

// ── Single-instance lock ───────────────────────────────────────────────────
const gotLock = app.requestSingleInstanceLock();
if (!gotLock) { app.quit(); process.exit(0); }

let mainWin = null;

app.on('second-instance', () => {
  if (mainWin) {
    if (mainWin.isMinimized()) mainWin.restore();
    mainWin.focus();
  }
});

// ── Create window ──────────────────────────────────────────────────────────
function createWindow() {
  const state = loadState();

  mainWin = new BrowserWindow({
    width:           state.width  || 1280,
    height:          state.height || 860,
    x:               state.x,
    y:               state.y,
    minWidth:        800,
    minHeight:       600,
    title:           'Claude',
    icon:            path.join(__dirname, 'assets', 'icon.png'),
    autoHideMenuBar: true,
    backgroundColor: '#1a1a2e',
    webPreferences: {
      contextIsolation: true,
      nodeIntegration:  false,
      spellcheck:       true,
      partition:        'persist:claude',   // login cookies survive restarts
    },
  });

  // Spoof a standard Chrome UA so claude.ai doesn't flag Electron
  mainWin.webContents.setUserAgent(
    'Mozilla/5.0 (X11; Linux x86_64) ' +
    'AppleWebKit/537.36 (KHTML, like Gecko) ' +
    'Chrome/122.0.0.0 Safari/537.36'
  );

  mainWin.loadURL('https://claude.ai');

  // Keep external links opening in the system browser
  mainWin.webContents.setWindowOpenHandler(({ url }) => {
    if (!url.startsWith('https://claude.ai')) shell.openExternal(url);
    return { action: 'deny' };
  });

  mainWin.webContents.on('will-navigate', (event, url) => {
    const allowed = [
      'claude.ai', 'anthropic.com',
      'accounts.google.com', 'github.com', 'appleid.apple.com'
    ];
    try {
      const { hostname } = new URL(url);
      if (!allowed.some(d => hostname.endsWith(d))) {
        event.preventDefault();
        shell.openExternal(url);
      }
    } catch {}
  });

  // Sync title bar with page title
  mainWin.webContents.on('page-title-updated', (_, title) => {
    mainWin.setTitle(title || 'Claude');
  });

  // Save size/position on close
  mainWin.on('close', () => saveState(mainWin));

  // ── Keyboard shortcuts ─────────────────────────────────────────────────
  mainWin.webContents.on('before-input-event', (event, input) => {
    if (!input.control || input.type !== 'keyDown') return;
    switch (input.key) {
      case 'r': case 'R':
        mainWin.webContents.reload();
        event.preventDefault(); break;
      case '=': case '+':
        mainWin.webContents.setZoomFactor(
          Math.min(mainWin.webContents.getZoomFactor() + 0.1, 3.0));
        event.preventDefault(); break;
      case '-':
        mainWin.webContents.setZoomFactor(
          Math.max(mainWin.webContents.getZoomFactor() - 0.1, 0.5));
        event.preventDefault(); break;
      case '0':
        mainWin.webContents.setZoomFactor(1.0);
        event.preventDefault(); break;
    }
  });

  // ── Right-click context menu ───────────────────────────────────────────
  mainWin.webContents.on('context-menu', (_, params) => {
    const items = [];
    if (params.selectionText) items.push({ label: 'Copy',  role: 'copy'  });
    if (params.isEditable)    items.push(
      { label: 'Cut',   role: 'cut'   },
      { label: 'Paste', role: 'paste' }
    );
    items.push(
      { type: 'separator' },
      { label: 'Reload', click: () => mainWin.webContents.reload() },
      { label: 'Back',   click: () => {
          if (mainWin.webContents.canGoBack()) mainWin.webContents.goBack();
      }},
      { type: 'separator' },
      { label: 'Zoom In  (Ctrl ++)', click: () =>
          mainWin.webContents.setZoomFactor(
            Math.min(mainWin.webContents.getZoomFactor() + 0.1, 3.0)) },
      { label: 'Zoom Out (Ctrl +-)', click: () =>
          mainWin.webContents.setZoomFactor(
            Math.max(mainWin.webContents.getZoomFactor() - 0.1, 0.5)) },
      { label: 'Reset Zoom (Ctrl+0)', click: () =>
          mainWin.webContents.setZoomFactor(1.0) }
    );
    Menu.buildFromTemplate(items).popup({ window: mainWin });
  });

  Menu.setApplicationMenu(null);
}

// ── App lifecycle ──────────────────────────────────────────────────────────
app.whenReady().then(createWindow);
app.on('window-all-closed', () => app.quit());
app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) createWindow();
});
