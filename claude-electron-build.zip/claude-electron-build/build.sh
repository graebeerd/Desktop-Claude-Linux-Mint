#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
#  build.sh — builds the Claude Linux AppImage
#  Run this once on your Linux machine.  After that, just use Claude.AppImage.
# ─────────────────────────────────────────────────────────────────────────────
set -e

CYAN='\033[0;36m'; GREEN='\033[0;32m'; RED='\033[0;31m'; NC='\033[0m'

info()  { echo -e "${CYAN}▶  $*${NC}"; }
ok()    { echo -e "${GREEN}✔  $*${NC}"; }
err()   { echo -e "${RED}✘  $*${NC}"; exit 1; }

info "Checking for Node.js..."
if ! command -v node &>/dev/null; then
  err "Node.js not found. Install it with:
    Ubuntu/Debian : sudo apt install nodejs npm
    Fedora        : sudo dnf install nodejs
    Arch          : sudo pacman -S nodejs npm
  Then re-run this script."
fi

NODE_VER=$(node -e "process.exit(process.versions.node.split('.')[0] < 18 ? 1 : 0)" 2>/dev/null && echo ok || echo old)
if [ "$NODE_VER" = "old" ]; then
  err "Node.js 18+ required. Your version: $(node --version)"
fi
ok "Node.js $(node --version) found."

info "Installing dependencies (this downloads Electron — may take a minute)..."
npm install

info "Building AppImage..."
npm run dist

APPIMAGE=$(find dist -name "*.AppImage" | head -1)
if [ -z "$APPIMAGE" ]; then
  err "Build succeeded but AppImage not found in dist/."
fi

cp "$APPIMAGE" ./Claude.AppImage
chmod +x ./Claude.AppImage

echo ""
ok "Done!  Claude.AppImage is ready in this folder."
echo -e "   Run it with:  ${CYAN}./Claude.AppImage${NC}"
echo -e "   Or double-click it in your file manager."
echo ""
echo "   You can move Claude.AppImage anywhere you like."
echo "   The build folder (node_modules, dist) can be deleted."
